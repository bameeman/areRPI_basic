﻿<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Raspberry Pi Gpio Robot</title>
    </head>
 
    <body style="background-color: black;">
     <!-- On/Off button's picture -->
	 <?php
	 $L1 = 22;
	 $L2 = 23;
	 $R1 = 24;
	 $R2 = 25;
	 //this php script generate the first page in function of the gpio's status
	 $status = array ( 0 , 0 , 0 , 0 );
	 $PIN = array ($L1, $L2, $R1, $R2);
	 for ($i = 0; $i < count($status); $i++) {
		//set the pin's mode to output and read them
		system("gpio mode ".$PIN[$i]." out");
		exec ("gpio read ".$PIN[$i], $status[$i], $return );
		//if off
		if ($status[$i][0] == 0 ) {
		echo ("<img id='button_".$i."' src='data/img/red/red_".$i.".jpg' alt='off'/>");
		}
		//if on
		if ($status[$i][0] == 1 ) {
		echo ("<img id='button_".$i."' src='data/img/green/green_".$i.".jpg' alt='on'/>");
		}	 
	 }
	 ?>
	 
	 <!-- javascript -->
	 <script src="script.js"></script>
    </body>
</html>
